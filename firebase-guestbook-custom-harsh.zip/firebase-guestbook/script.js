// Firebase Guestbook App by Harsh Pandav
// Replace the config object below with your Firebase project credentials from Firebase Console

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  databaseURL: "https://YOUR_PROJECT_ID.firebaseio.com",
  projectId: "YOUR_PROJECT_ID",
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();

// Add an entry to the database
function addEntry() {
  const name = document.getElementById("name").value;
  const msg = document.getElementById("message").value;
  if (name && msg) {
    db.ref("entries").push({ name, msg });
    document.getElementById("name").value = "";
    document.getElementById("message").value = "";
  }
}

// Listen for new entries and display them live
db.ref("entries").on("child_added", (snapshot) => {
  const data = snapshot.val();
  const li = document.createElement("li");
  li.textContent = `${data.name}: ${data.msg}`;
  document.getElementById("entries").appendChild(li);
});